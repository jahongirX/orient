<?php

$this->title = Yii::t('main', 'Home');

?>

<div class="container-fluid bg-white m-t-50">

    <div class="panel panel-transparent">

        <div class="panel-heading">

            <div class="clearfix"></div>

        </div>

        <div class="panel-body">



        </div>

    </div>

</div>